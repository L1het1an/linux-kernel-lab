# -*- coding: utf-8 -*-
"""从 dataset_centroids.h 提取 3x99 数值，生成驱动用的 body 文件。"""
import os
import re

HOME = os.environ["USERPROFILE"]
SRC = os.path.join(HOME, "Pictures", "dataset", "kernel_patch", "kernel",
                   "dataset_centroids.h")
DST = os.path.join(HOME, "Pictures", "driver", "dataset_centroids_body.h")

text = open(SRC, encoding="utf-8").read()
text = re.sub(r"/\*.*?\*/", " ", text, flags=re.S)
text = re.sub(r"//[^\n]*", " ", text)

m = re.search(r"=\s*\{(.*)\}\s*;", text, flags=re.S)
assert m, "没找到初始化块"
body = m.group(1)

nums = re.findall(r"[-+]?\d+\.\d+(?:[eE][-+]?\d+)?|[-+]?\d+", body)
assert len(nums) == 297, "数值个数 %d != 297" % len(nums)

lines = ["/* 自动生成，来自 dataset_centroids.h，3 x 99 = 297 个 double */", "{"]
for i in range(0, len(nums), 6):
    lines.append("\t" + ", ".join(nums[i:i + 6]) + ",")
lines.append("}")

with open(DST, "w", encoding="utf-8") as f:
    f.write("\n".join(lines) + "\n")

print("OK", len(nums), "values ->", DST)
