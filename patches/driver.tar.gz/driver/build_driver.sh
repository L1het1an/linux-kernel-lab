#!/bin/bash
# build_driver.sh - 一键构建并测试 /dev/dataset 字符设备驱动
#
# 用法（在虚拟机任意目录）:
#   bash ~/kernel_exp/driver/build_driver.sh
#
# 前提:
#   1. 当前内核是 5.15.0（自编内核），/lib/modules/$(uname -r)/build 存在
#   2. ~/kernel_exp/linux-5.15/kernel/dataset_centroids.h 存在
#   3. ~/kernel_exp/userspace/test_samples.bin 存在
#
# 脚本会:
#   1. 从类中心头文件生成驱动所需的 body 文件
#   2. 编译模块
#   3. 加载模块并检查 /dev/dataset
#   4. 编译并运行用户态测试程序

set -e

DRV_DIR="$HOME/kernel_exp/driver"
KERNEL_DIR="$HOME/kernel_exp/linux-5.15"
SAMPLE="$HOME/kernel_exp/userspace/test_samples.bin"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "=========================================="
echo " 0/5  环境检查"
echo "=========================================="
KVER=$(uname -r)
echo "当前内核: $KVER"

if [ ! -d "/lib/modules/$KVER/build" ]; then
    echo "[ERROR] /lib/modules/$KVER/build 不存在"
    echo "        模块编译需要内核头文件/构建目录。"
    echo "        如果你当前不在 5.15.0 内核上，请先重启进 5.15.0。"
    exit 1
fi

if [ ! -f "$KERNEL_DIR/kernel/dataset_centroids.h" ]; then
    echo "[ERROR] 找不到 $KERNEL_DIR/kernel/dataset_centroids.h"
    exit 1
fi

if [ ! -f "$SAMPLE" ]; then
    echo "[WARN] 找不到测试样本 $SAMPLE（只编译，不测试）"
    HAVE_SAMPLE=0
else
    HAVE_SAMPLE=1
fi

mkdir -p "$DRV_DIR"
cd "$DRV_DIR"

# 把脚本同目录的源文件拷进来（若源目录就是目标目录则跳过）
if [ "$SRC_DIR" != "$DRV_DIR" ]; then
    for f in dataset_dev.c dataset_test.c Makefile dataset_centroids_body.h; do
        if [ -f "$SRC_DIR/$f" ]; then
            cp -f "$SRC_DIR/$f" "$DRV_DIR/$f" || true
        fi
    done
fi

echo "工作目录: $DRV_DIR"
echo

echo "=========================================="
echo " 1/5  生成类中心 body 文件"
echo "=========================================="
python3 - "$KERNEL_DIR/kernel/dataset_centroids.h" "$DRV_DIR/dataset_centroids_body.h" << 'PYEOF'
import re, sys

src, dst = sys.argv[1], sys.argv[2]
text = open(src, encoding="utf-8", errors="ignore").read()

# 去掉注释和预处理指令
text = re.sub(r"/\*.*?\*/", " ", text, flags=re.S)
text = re.sub(r"//[^\n]*", " ", text)

# 找出所有形如 { ... } 的初始化块
blocks = re.findall(r"\{([^{}]*)\}", text, flags=re.S)
if not blocks:
    sys.exit("[ERROR] 在头文件里没找到 { ... } 初始化块")

# 取数字最多的那个块
best = max(blocks, key=lambda b: len(re.findall(r"[-+]?\d+\.\d+(?:[eE][-+]?\d+)?|[-+]?\d+(?:[eE][-+]?\d+)?", b)))
nums = re.findall(r"[-+]?(?:\d+\.\d+(?:[eE][-+]?\d+)?|\d+(?:[eE][-+]?\d+)?|[A-Za-z_]\w*)", best)

# 过滤掉宏名（NAN/INFINITY 之类保留），只保留数
count = len([n for n in nums if re.match(r"^[-+]?[\d.]", n) or n in ("NAN", "INFINITY")])
if count != 297:
    print("[WARN] 解析到 %d 个数值，预期 297（3x99）" % count)

with open(dst, "w", encoding="utf-8") as f:
    f.write("/* 自动生成，来自 %s */\n" % src)
    f.write("{\n")
    vals = [n for n in nums if re.match(r"^[-+]?[\d.]", n) or n in ("NAN", "INFINITY")]
    for i in range(0, len(vals), 6):
        chunk = vals[i:i+6]
        f.write("\t" + ", ".join(chunk) + ",\n")
    f.write("}\n")

print("[OK] 生成 %s，共 %d 个数值" % (dst, len(vals)))
PYEOF
echo

echo "=========================================="
echo " 2/5  编译内核模块"
echo "=========================================="
make clean > /dev/null 2>&1 || true
if make 2>&1 | tail -25; then
    echo
else
    echo "[ERROR] 编译失败，见上方输出"
    exit 1
fi

if [ ! -f dataset_dev.ko ]; then
    echo "[ERROR] 没有生成 dataset_dev.ko"
    exit 1
fi
ls -lh dataset_dev.ko
echo

echo "=========================================="
echo " 3/5  加载模块"
echo "=========================================="
sudo rmmod dataset_dev 2>/dev/null || true
sudo insmod ./dataset_dev.ko
sleep 0.5

echo "--- dmesg 最后 5 行 ---"
sudo dmesg | tail -5
echo

if [ ! -c /dev/dataset ]; then
    echo "[ERROR] /dev/dataset 没有创建"
    exit 1
fi
ls -l /dev/dataset
echo

echo "=========================================="
echo " 4/5  编译用户态测试程序"
echo "=========================================="
gcc -O2 -Wall -o dataset_test dataset_test.c
ls -lh dataset_test
echo

echo "=========================================="
echo " 5/5  运行测试"
echo "=========================================="
if [ "$HAVE_SAMPLE" = "1" ]; then
    ./dataset_test "$SAMPLE" | tail -6
    echo
    echo "--- 完整统计 ---"
    ./dataset_test "$SAMPLE" | tail -1
else
    echo "跳过（没有测试样本）"
fi

echo
echo "=========================================="
echo " 完成"
echo "=========================================="
echo "卸载模块: sudo rmmod dataset_dev"
echo "重新加载: sudo insmod $DRV_DIR/dataset_dev.ko"
echo "运行测试: $DRV_DIR/dataset_test $SAMPLE"
