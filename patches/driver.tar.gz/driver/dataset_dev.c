// SPDX-License-Identifier: GPL-2.0
/*
 * dataset_dev.c - dataset classifier char device
 *
 * write()  : 15840 bytes (60x33 doubles) -> classify
 * read()   : struct dataset_result (24 bytes)
 *
 * 与第 548 号系统调用 kernel_dataset_classify 算法一致，
 * 入口从 syscall 换成 VFS 文件操作。类中心内联，无外部头文件依赖。
 */
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/miscdevice.h>
#include <linux/uaccess.h>
#include <linux/slab.h>
#include <linux/mutex.h>
#include <linux/device.h>
#include <linux/ktime.h>
#include <linux/atomic.h>
#include <asm/fpu/api.h>

#define TS_SAMPLES      60
#define TS_CHANNELS     33
#define TS_FEATDIM      (TS_CHANNELS * 3)
#define DS_NCLASS       3
#define DS_SAMPLE_BYTES (TS_SAMPLES * TS_CHANNELS * sizeof(double))

struct dataset_result {
    int    predict_class;
    double min_distance;
    double margin;
};

/* offline trained centroids, 3 classes x 99 features, index c*99+i */
static const double DS_CLASS_CENTROID[DS_NCLASS * TS_FEATDIM] = {
    1.01146839, 1.02643119, 0.99742623, 1.01163222, -0.00653295, 1.00000000,
    0.99954642, 1.49573892, 0.02915887, 1.00785827, 1.00788917, -0.04107447,
    -0.00224865, -0.35887182, -0.04493258, -0.01311928, -0.13170588, -0.04496901,
    0.46698978, -0.15747087, 1.05767541, -0.00331673, -0.00000197, 1.00000000,
    0.06352417, 0.48939173, 0.47442658, 1.18101158, 0.03769699, 98.36557820,
    0.92150076, 0.00004266, 0.00003670, 0.04539224, 0.04714669, 0.04370206,
    0.04524049, 1.95699770, 0.57754149, 0.60766190, 0.90806905, 0.01512243,
    0.04276366, 0.04136202, 0.24431135, 0.04563037, 2.42238752, 0.22691430,
    0.33149138, 3.28176171, 1.02597532, 0.20161222, 5.77395514, 0.58940917,
    0.07275369, 0.00000584, 0.60115986, 0.48081559, 0.10530304, 0.11513917,
    0.37806215, 0.01367518, 7.99543890, 0.08865569, 0.00960743, 0.01101753,
    0.18695018, 0.19258698, 0.17563111, 0.18297062, 11.28568870, 2.99699053,
    3.17068709, 4.63412027, 0.07657137, 0.15499366, 0.14872755, 0.86046996,
    0.21279325, 8.55207939, 0.76652074, 1.29651647, 15.31863248, 4.54790105,
    0.69619569, 24.52795071, 3.39396690, 0.34130936, 0.00002148, 2.12540129,
    1.61839686, 0.49072288, 0.45886206, 1.61643445, 0.04624015, 31.64803055,
    0.36434045, 0.05026770, 0.05792835, 1.01027514, 1.02514874, 0.99630664,
    1.01052594, -0.00147758, 1.00000000, 0.99954727, 1.48378371, 0.02902768,
    1.01540225, 1.01541779, -0.02942121, -0.00267431, -0.33717359, -0.03941748,
    -0.02345983, -0.18528410, -0.05927238, 0.46613815, -0.28939908, 1.05075400,
    -0.00175226, -0.00000169, 1.00000000, 0.05740487, 0.48914568, 0.46728665,
    1.17973616, 0.03328449, 98.64209242, 0.93186907, 0.00026561, 0.00022797,
    0.04479513, 0.04652084, 0.04308831, 0.04465053, 1.93935252, 0.57604525,
    0.60532525, 0.89773154, 0.01495595, 0.03928861, 0.03806445, 0.16936232,
    0.04046532, 2.15631939, 0.20343422, 0.33454470, 2.89354668, 1.02787302,
    0.20323584, 5.11007490, 0.56344006, 0.07152216, 0.00000494, 0.60197898,
    0.47194106, 0.10412506, 0.11695808, 0.38136654, 0.01250475, 6.87453797,
    0.08603134, 0.01028753, 0.01174066, 0.18483028, 0.19026674, 0.17313725,
    0.18081426, 11.15258610, 2.98693039, 3.15574001, 4.56949951, 0.07569054,
    0.14147688, 0.13573122, 0.58883830, 0.18980187, 7.59478228, 0.68097578,
    1.30801179, 13.56034953, 4.57954166, 0.69965232, 21.74884753, 3.25099235,
    0.33585516, 0.00001819, 2.11855280, 1.61184833, 0.48671755, 0.46359218,
    1.62230866, 0.04173567, 27.05371864, 0.35038467, 0.05628460, 0.06421471,
    1.00933325, 1.02394550, 0.99553888, 1.00954616, 0.00269834, 1.00000000,
    1.00000000, 1.41755550, 0.02860857, 1.00996800, 1.01000121, -0.04064467,
    -0.00232066, -0.37930458, -0.04598193, -0.01508234, -0.14310281, -0.04585012,
    0.46935318, -0.18768473, 1.05274256, -0.00250073, -0.00000196, 1.00000000,
    0.05768029, 0.48848449, 0.47248704, 1.18192042, 0.03796578, 98.42537346,
    0.92726491, 0.00013748, 0.00011863, 0.04454182, 0.04617621, 0.04274521,
    0.04434181, 1.90861305, 0.57467038, 0.60307338, 0.87124544, 0.01468830,
    0.04223709, 0.04082041, 0.20768987, 0.04595218, 2.45283301, 0.22820784,
    0.32933016, 3.28899494, 1.02249222, 0.20253603, 5.79446564, 0.56850343,
    0.07207538, 0.00000577, 0.59548983, 0.47671910, 0.10525278, 0.11592343,
    0.37772272, 0.01411177, 7.83129889, 0.08360377, 0.01043629, 0.01214173,
    0.18331825, 0.18816346, 0.17100171, 0.17898847, 11.01985814, 2.98538236,
    3.15104032, 4.44220496, 0.07431352, 0.15431062, 0.14794356, 0.72862508,
    0.21413524, 8.66768278, 0.76718599, 1.29528148, 15.32149156, 4.52203553,
    0.69891200, 24.73940641, 3.26350466, 0.33689267, 0.00002123, 2.10767019,
    1.61375416, 0.48997313, 0.46078356, 1.60211892, 0.04737517, 31.05391983,
    0.34167903, 0.05734750, 0.06644061,
};

static struct dataset_result g_result;
static DEFINE_MUTEX(g_lock);

/* 性能统计：调用次数与累计耗时（纳秒） */
static atomic64_t g_calls = ATOMIC64_INIT(0);
static atomic64_t g_total_ns = ATOMIC64_INIT(0);

/*
 * 定点缓存：内核 vsnprintf 不支持 %f，故在 FPU 保护区内把 double
 * 换算成放大 10000 倍的整数，供 sysfs 用纯整数格式化输出。
 */
static long g_md_int;
static long g_mg_int;

/* Newton iteration sqrt, avoid libm */
static double my_sqrt(double a)
{
    double x;
    int k;

    if (a <= 0.0)
        return 0.0;

    x = a > 1.0 ? a : 1.0;
    for (k = 0; k < 30; k++)
        x = 0.5 * (x + a / x);

    return x;
}

/* must be called inside kernel_fpu_begin()/end() */
static void dataset_classify(const double *buf, struct dataset_result *out)
{
    double feat[TS_FEATDIM];
    double dist[DS_NCLASS];
    double second;
    int i, j, c, r;

    for (j = 0; j < TS_CHANNELS; j++) {
        double sum = 0.0, sum2 = 0.0, mn = 1e300, mx = -1e300;

        for (i = 0; i < TS_SAMPLES; i++) {
            double v = buf[i * TS_CHANNELS + j];

            sum += v;
            sum2 += v * v;
            if (v < mn)
                mn = v;
            if (v > mx)
                mx = v;
        }
        feat[j] = sum / TS_SAMPLES;
        feat[j + TS_CHANNELS] = my_sqrt(sum2 / TS_SAMPLES -
                (sum / TS_SAMPLES) * (sum / TS_SAMPLES));
        feat[j + 2 * TS_CHANNELS] = mx - mn;
    }

    for (c = 0; c < DS_NCLASS; c++) {
        double d = 0.0;

        for (i = 0; i < TS_FEATDIM; i++) {
            double diff = feat[i] -
                DS_CLASS_CENTROID[c * TS_FEATDIM + i];

            d += diff * diff;
        }
        dist[c] = my_sqrt(d);
    }

    r = 0;
    for (c = 1; c < DS_NCLASS; c++)
        if (dist[c] < dist[r])
            r = c;

    second = 1e300;
    for (c = 0; c < DS_NCLASS; c++)
        if (c != r && dist[c] < second)
            second = dist[c];

    out->predict_class = r;
    out->min_distance = dist[r];
    out->margin = second - dist[r];
}

static ssize_t dataset_write(struct file *f, const char __user *ubuf,
                             size_t len, loff_t *off)
{
    double *buf;
    int ret;
    u64 t0, t1;

    if (len != DS_SAMPLE_BYTES)
        return -EINVAL;

    buf = kmalloc(DS_SAMPLE_BYTES, GFP_KERNEL);
    if (!buf)
        return -ENOMEM;

    if (copy_from_user(buf, ubuf, DS_SAMPLE_BYTES)) {
        ret = -EFAULT;
        goto out_free;
    }

    t0 = ktime_get_ns();
    mutex_lock(&g_lock);
    kernel_fpu_begin();
    dataset_classify(buf, &g_result);
    /* 浮点转定点，必须在 FPU 保护区之内完成 */
    g_md_int = (long)(g_result.min_distance * 10000.0);
    g_mg_int = (long)(g_result.margin * 10000.0);
    kernel_fpu_end();
    mutex_unlock(&g_lock);
    t1 = ktime_get_ns();

    atomic64_inc(&g_calls);
    atomic64_add(t1 - t0, &g_total_ns);

    ret = len;
out_free:
    kfree(buf);
    return ret;
}

static ssize_t dataset_read(struct file *f, char __user *ubuf,
                            size_t len, loff_t *off)
{
    if (*off >= sizeof(g_result))
        return 0;
    if (len < sizeof(g_result))
        return -EINVAL;
    if (copy_to_user(ubuf, (const void *)&g_result, sizeof(g_result)))
        return -EFAULT;
    *off += sizeof(g_result);
    return sizeof(g_result);
}

/* 允许 read 重置偏移：用户态需要 lseek(fd,0,SEEK_SET) 反复读同一结果 */
static loff_t dataset_llseek(struct file *f, loff_t off, int whence)
{
    loff_t newpos;

    switch (whence) {
    case SEEK_SET:
        newpos = off;
        break;
    case SEEK_CUR:
        newpos = f->f_pos + off;
        break;
    case SEEK_END:
        newpos = sizeof(g_result) + off;
        break;
    default:
        return -EINVAL;
    }
    if (newpos < 0)
        return -EINVAL;
    f->f_pos = newpos;
    return newpos;
}

static const struct file_operations dataset_fops = {
    .owner = THIS_MODULE,
    .write = dataset_write,
    .read  = dataset_read,
    .llseek = dataset_llseek,
};

static struct miscdevice dataset_miscdev = {
    .minor = MISC_DYNAMIC_MINOR,
    .name  = "dataset",
    .fops  = &dataset_fops,
    .mode  = 0666,
};

/*
 * sysfs 只读属性：/sys/class/misc/dataset/last_result
 * 展示最近一次分类结果，便于 shell 直接查看而无需编写程序。
 */
static ssize_t last_result_show(struct device *dev,
                                struct device_attribute *attr, char *buf)
{
    return sprintf(buf,
                   "predict_class=%d min_distance=%ld.%04ld margin=%ld.%04ld\n",
                   g_result.predict_class,
                   g_md_int / 10000, g_md_int % 10000,
                   g_mg_int / 10000, g_mg_int % 10000);
}
static DEVICE_ATTR_RO(last_result);

/*
 * sysfs 只读属性：/sys/class/misc/dataset/stats
 * 展示调用次数与累计/平均耗时（微秒），用于定量评估内核态开销。
 */
static ssize_t stats_show(struct device *dev,
                          struct device_attribute *attr, char *buf)
{
    u64 calls = (u64)atomic64_read(&g_calls);
    u64 total = (u64)atomic64_read(&g_total_ns);

    return sprintf(buf, "calls=%llu\ntotal_us=%llu\navg_us=%llu\n",
                   calls,
                   (unsigned long long)div_u64(total, 1000),
                   (unsigned long long)(calls ?
                       div_u64(total, calls * 1000) : 0));
}
static DEVICE_ATTR_RO(stats);

static int __init dataset_init(void)
{
    int ret = misc_register(&dataset_miscdev);

    if (ret) {
        pr_err("dataset: misc_register failed: %d\n", ret);
        return ret;
    }

    ret = device_create_file(dataset_miscdev.this_device,
                             &dev_attr_last_result);
    if (ret) {
        pr_err("dataset: create last_result failed: %d\n", ret);
        goto err_misc;
    }

    ret = device_create_file(dataset_miscdev.this_device, &dev_attr_stats);
    if (ret) {
        pr_err("dataset: create stats failed: %d\n", ret);
        device_remove_file(dataset_miscdev.this_device,
                           &dev_attr_last_result);
        goto err_misc;
    }

    pr_info("dataset: /dev/dataset ready, sample=%u bytes\n",
            (unsigned int)DS_SAMPLE_BYTES);
    return 0;

err_misc:
    misc_deregister(&dataset_miscdev);
    return ret;
}

static void __exit dataset_exit(void)
{
    device_remove_file(dataset_miscdev.this_device, &dev_attr_stats);
    device_remove_file(dataset_miscdev.this_device, &dev_attr_last_result);
    misc_deregister(&dataset_miscdev);
    pr_info("dataset: unloaded\n");
}

module_init(dataset_init);
module_exit(dataset_exit);
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Dataset classifier char device");
MODULE_AUTHOR("thw");
