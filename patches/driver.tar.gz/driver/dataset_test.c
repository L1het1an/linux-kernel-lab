/* dataset_test.c - 通过 /dev/dataset 字符设备做分类
 *
 * 用法: ./dataset_test test_samples.bin
 *
 * 文件格式（与系统调用版本相同）:
 *   [int64 label][1980 个 double]  重复 200 次
 *   每条记录 = 8 + 15840 = 15848 字节，200 条 = 3169600 字节
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <fcntl.h>
#include <unistd.h>

#define TS_SAMPLES      60
#define TS_CHANNELS     33
#define DS_SAMPLE_BYTES (TS_SAMPLES * TS_CHANNELS * sizeof(double))

struct dataset_result {
	int	predict_class;
	double	min_distance;
	double	margin;
};

int main(int argc, char **argv)
{
	int64_t label;
	int pred, ok = 0, total = 0;
	double samples[TS_SAMPLES * TS_CHANNELS];
	struct dataset_result res;
	FILE *fp;
	int fd;

	if (argc < 2) {
		fprintf(stderr, "usage: %s <samples.bin>\n", argv[0]);
		return 1;
	}

	fd = open("/dev/dataset", O_RDWR);
	if (fd < 0) {
		perror("open /dev/dataset");
		return 1;
	}

	fp = fopen(argv[1], "rb");
	if (!fp) {
		perror("fopen");
		close(fd);
		return 1;
	}

	while (1) {
		/* 文件格式: [15840 字节样本][8 字节 int64 标签] */
		if (fread(samples, 1, DS_SAMPLE_BYTES, fp) != DS_SAMPLE_BYTES)
			break;
		if (fread(&label, sizeof(label), 1, fp) != 1)
			break;

		if (write(fd, samples, DS_SAMPLE_BYTES) != DS_SAMPLE_BYTES) {
			perror("write");
			break;
		}

		/* read 前必须复位偏移，否则第二次 read 直接返回 0 */
		lseek(fd, 0, SEEK_SET);

		if (read(fd, &res, sizeof(res)) != sizeof(res)) {
			perror("read");
			break;
		}

		pred = res.predict_class;
		total++;
		if (pred == (int)label)
			ok++;

		printf("#%3d 真实=%d 预测=%d 距离=%.4f margin=%.4f [%s]\n",
		       total - 1, (int)label, pred, res.min_distance,
		       res.margin, pred == (int)label ? "OK" : "X");
	}

	printf("\n准确率: %d / %d = %.2f%%\n", ok, total,
	       total ? 100.0 * ok / total : 0.0);

	fclose(fp);
	close(fd);
	return 0;
}
